﻿using Dieren;

var vis = new Vis() { Naam = "Vleermuis" };
var vogel = new Vogel() { Naam = "Vleermuis" };
var freek = new Freek();
var zoogdier = new Zoogdier();
var kraai = new Kraai { Naam = "Kraai" };
var struisvogel = new Struisvogel() { Naam = "Struisvogel" };
var vleermuis = new Vleermuis() { Naam = "Vleermuis" };
var mol = new Mol() { Naam = "Mol" };

mol.Baar();
vleermuis.Baar();
