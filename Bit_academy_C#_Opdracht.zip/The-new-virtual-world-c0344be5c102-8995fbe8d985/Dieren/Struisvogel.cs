﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieren
{
    public class Struisvogel : Vogel
    {
        public override void Praat()
        {
            Console.WriteLine("Struisvogel zegt Tjilp Tjilp");
        }
    }
}
