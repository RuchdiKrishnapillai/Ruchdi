﻿namespace Dieren
{
    public abstract class Dier
    {
        public string Naam { get; set; } = "dier";
        public void Eet()
        {
            Console.WriteLine("Eten");
        }
        public void Slaap()
        {
            Console.WriteLine("Slapen");
        }

        public abstract void Praat();
    }
}