﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieren
{
    public class Vleermuis : Zoogdier, IVlieger
    {
        public void Vlieg()
        {
            Console.WriteLine("Liftoff.. Fladder");
        }
        public override void Praat()
        {
            Console.WriteLine("Vleermuis zegt Tjilp Tjilp");
        }
        public override void Baar()
        {
            Console.WriteLine("Ik baar Vleermuisjes");
        }
    }
}
