﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieren
{
    public class Mol : Zoogdier
    {
        public override void Praat()
        {
            Console.WriteLine("Mol praat");
        }
        public override void Baar()
        {
            Console.WriteLine("Ik baar molletjes");
        }
    }
}
