﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Dieren
{
    public class Freek
    {
        public void GeefEten(Dier dier)
        {
            Console.WriteLine("lekker!");
        }

        public void BrengNaarBed(Dier dier)
        {
            Console.WriteLine("ZZZZzzzzz....");
        }

        public void PraatMetDier(Dier dier)
        {
            Console.WriteLine("Freek praat met vogel");
            dier.Praat();
        }

        public void LaatVliegen(Dier dier)
        {
            if (dier is IVlieger AanHetVliegen)
            {
                Console.WriteLine($"Freek laat {dier.Naam} vliegen");
                AanHetVliegen.Vlieg();
            }
        }
    }
}
