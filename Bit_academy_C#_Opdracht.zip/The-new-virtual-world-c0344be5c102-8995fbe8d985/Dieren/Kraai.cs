﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieren
{
    public class Kraai : Vogel, IVlieger
    {
        public void Vlieg()
        {
            Console.WriteLine("Liftoff.. Fladder");
        }
        public override void Praat()
        {
            Console.WriteLine("Kraai zegt Tjilp Tjilp");
        }
    }
}
