﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dieren
{
    public class Zoogdier : Dier
    {
        public override void Praat()
        {
            Console.WriteLine("Zoogdier zegt .....");
        }
        public virtual void Baar()
        {
            Console.WriteLine("Ik baar Zoogdieren");
        }
    }
}
